import React, { useState, useEffect, useRef } from 'react';
import { PhaseIndicator } from './components/PhaseIndicator';
import { SECTIONS } from './constants';
import { SectionData } from './types';
import { Play } from 'lucide-react';

export default function App() {
  const [activeSection, setActiveSection] = useState<string>(SECTIONS[0].id);
  const sectionRefs = useRef<{[key: string]: HTMLElement | null}>({});

  useEffect(() => {
    const observers = new Map();

    const callback: IntersectionObserverCallback = (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          // Set active section when >50% visible
          setActiveSection(entry.target.id);
        }
      });
    };

    const observer = new IntersectionObserver(callback, {
      root: null,
      rootMargin: '-40% 0px -40% 0px', // Trigger when element is in the middle 20% of screen
      threshold: 0
    });

    SECTIONS.forEach((section) => {
      const el = sectionRefs.current[section.id];
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const scrollToSection = (id: string) => {
    const el = sectionRefs.current[id];
    if (el) {
      // Need to account for double sticky headers (Main Header + Phase Header)
      // Main header is ~73px, Phase header is ~80px.
      const offset = 160; 
      const elementPosition = el.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Get current active visual content
  const activeSectionData = SECTIONS.find(s => s.id === activeSection) || SECTIONS[0];

  return (
    <div className="min-h-screen bg-canvas text-primary font-sans selection:bg-accent selection:text-white">
      
      {/* 1. Global Navbar (Standard Site Nav) */}
      <header className="sticky top-0 z-50 bg-canvas/90 backdrop-blur-md border-b border-gray-100 h-[73px]">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          
          {/* Logo Section */}
          <div className="flex items-center gap-8">
            <div className="font-bold text-xl tracking-tighter flex items-center gap-2 cursor-pointer">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-primary">
                <path d="M12 2L2 22H22L12 2Z" fill="currentColor"/>
              </svg>
              <span>Adaline</span>
            </div>
            
            {/* Nav Links */}
            <nav className="hidden md:flex items-center gap-6 text-xs font-medium uppercase tracking-wider text-gray-500">
              <a href="#" className="hover:text-primary transition-colors">Products</a>
              <a href="#" className="hover:text-primary transition-colors">Pricing</a>
              <a href="#" className="hover:text-primary transition-colors">Blog</a>
            </nav>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-4">
             <button className="hidden sm:flex items-center gap-2 px-4 py-2 rounded-full border border-gray-200 text-xs font-mono hover:bg-gray-50 transition-colors">
                WATCH DEMO <Play size={10} className="fill-current" />
             </button>
             <button className="bg-primary text-white px-5 py-2 rounded-full text-xs font-mono hover:bg-accent transition-colors">
               START FOR FREE
             </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto w-full">
        <div className="flex flex-col md:flex-row">
          
          {/* Left Column: Narrative Content */}
          <div className="w-full md:w-1/2 relative border-r border-dashed border-gray-200">
             
             {/* 2. Secondary Sticky Header: Phase Indicators */}
             <div className="sticky top-[73px] z-40 bg-canvas/95 backdrop-blur-sm border-b border-dashed border-gray-200 py-4 px-6 md:px-12 transition-all">
               <div className="flex items-center justify-start gap-4 md:gap-8 overflow-x-auto no-scrollbar mask-gradient">
                  {SECTIONS.map((section, index) => {
                     const currentIndex = SECTIONS.findIndex(s => s.id === activeSection);
                     const isCompleted = index < currentIndex;
                     const isActive = section.id === activeSection;

                     return (
                      <PhaseIndicator
                        key={section.id}
                        number={section.stepNumber}
                        label={section.title}
                        isActive={isActive}
                        isCompleted={isCompleted}
                        onClick={() => scrollToSection(section.id)}
                      />
                     );
                  })}
               </div>
             </div>

             {/* Background Grid Line decorative */}
             <div className="absolute inset-y-0 right-0 w-px bg-dashed-grid"></div>

             {/* Scrollable Text Sections */}
             {SECTIONS.map((section) => (
               <section 
                  key={section.id}
                  id={section.id}
                  ref={el => sectionRefs.current[section.id] = el}
                  className="min-h-[80vh] flex flex-col justify-center px-6 py-20 md:py-24 md:px-12 lg:px-20 border-b border-dashed border-gray-200 last:border-0 relative"
               >
                 <div className="mb-8">
                   <div className="flex items-center gap-3 mb-6">
                      <div className="h-px w-8 bg-primary/40"></div>
                      <span className="font-mono text-xs text-gray-500 uppercase tracking-widest">{section.subtitle}</span>
                   </div>
                   <h2 className="text-3xl md:text-4xl font-bold leading-tight mb-6">
                     {section.title}
                   </h2>
                   <p className="text-lg text-gray-600 leading-relaxed font-light">
                     {section.description}
                   </p>
                 </div>

                 {/* Sub-points / Details List */}
                 <div className="space-y-6 mt-8">
                    {section.subPoints.map((point, idx) => (
                      <div key={idx} className="group">
                        <div className="flex items-baseline gap-4 mb-2">
                          <span className="text-xs font-mono text-gray-400 group-hover:text-primary transition-colors">
                             {section.stepNumber}.{idx + 1}
                          </span>
                          <h4 className="text-xs font-bold uppercase tracking-wide text-gray-800">{point.label}</h4>
                        </div>
                        <p className="text-gray-500 text-sm pl-8 md:pl-10 border-l border-gray-200 group-hover:border-primary/30 transition-colors">
                          {point.text}
                        </p>
                      </div>
                    ))}
                 </div>
                 
                 {/* Mobile-only visual injection */}
                 <div className="md:hidden mt-12 h-64 w-full rounded-lg overflow-hidden shadow-inner border border-gray-200 bg-gray-50">
                    {section.visual}
                 </div>
               </section>
             ))}
             
             {/* Footer inside the scrollable area */}
             <footer className="py-12 px-6 md:px-20 border-t border-dashed border-gray-200">
               <div className="flex flex-col gap-4 text-sm text-gray-500 font-mono">
                 <p>© {new Date().getFullYear()} Adaline Clone. All rights reserved.</p>
                 <p>Designed with <span className="text-red-400">♥</span> and React.</p>
               </div>
             </footer>
          </div>

          {/* Right Column: Visual Context (Sticky) */}
          <div className="hidden md:block w-1/2 relative">
             <div className="sticky top-[73px] h-[calc(100vh-73px)] w-full p-8 lg:p-12 overflow-hidden flex items-center justify-center bg-[#FBFBF9]">
                {/* 
                   We use a key here to force React to remount the component when activeSection changes.
                   This triggers any entry animations inside the Visual components.
                */}
                <div key={activeSection} className="w-full h-full max-h-[600px] animate-[fadeInScale_0.6s_cubic-bezier(0.16,1,0.3,1)]">
                   {activeSectionData.visual}
                </div>
                
                {/* Decorative background grid specifically for the visual area */}
                <div className="absolute inset-0 pointer-events-none -z-10 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:16px_16px] opacity-50"></div>
             </div>
          </div>

        </div>
      </main>
      
      {/* Global CSS for custom animations */}
      <style>{`
        @keyframes grow {
          from { transform: scaleX(0); }
          to { transform: scaleX(1); }
        }
        @keyframes fadeInScale {
          from { 
            opacity: 0; 
            transform: scale(0.95) translateY(10px); 
          }
          to { 
            opacity: 1; 
            transform: scale(1) translateY(0); 
          }
        }
        /* Mask for horizontal scroll fade */
        .mask-gradient {
          mask-image: linear-gradient(to right, black 85%, transparent 100%);
        }
      `}</style>
    </div>
  );
}