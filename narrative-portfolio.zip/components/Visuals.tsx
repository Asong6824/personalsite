import React from 'react';
import { Terminal, Code2, Cpu, Globe, ArrowUpRight, Zap, Database, Layout } from 'lucide-react';

// Visual for "Origins" - Abstract representation of data/structure
export const OriginsVisual = () => (
  <div className="w-full h-full bg-[#F3F4F1] border border-dashed border-gray-300 p-8 relative overflow-hidden flex flex-col items-center justify-center">
    <div className="absolute inset-0 bg-dashed-grid opacity-50"></div>
    <div className="relative z-10 text-center">
      <div className="w-24 h-24 bg-primary text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-2xl">
        <span className="font-mono text-3xl font-bold">JD</span>
      </div>
      <h3 className="text-2xl font-bold mb-2">John Doe</h3>
      <p className="text-gray-500 font-mono text-sm">Full Stack Engineer &<br/>Creative Technologist</p>
      
      <div className="mt-8 grid grid-cols-2 gap-4 text-xs font-mono text-gray-600">
        <div className="bg-white px-3 py-2 border border-gray-200 rounded">LOC: San Francisco</div>
        <div className="bg-white px-3 py-2 border border-gray-200 rounded">EXP: 6+ Years</div>
      </div>
    </div>
    
    {/* Decorative Elements */}
    <div className="absolute top-10 right-10 opacity-20">
      <Cpu size={120} />
    </div>
    <div className="absolute bottom-10 left-10 opacity-20">
      <Globe size={120} />
    </div>
  </div>
);

// Visual for "Craft" - Tech Stack Grid
export const CraftVisual = () => (
  <div className="w-full h-full bg-white border border-gray-200 p-8 shadow-sm flex flex-col">
    <div className="border-b border-gray-100 pb-4 mb-6 flex justify-between items-center">
      <h4 className="font-mono text-xs uppercase text-gray-400">System Capabilities</h4>
      <div className="flex gap-1">
        <div className="w-2 h-2 rounded-full bg-red-400"></div>
        <div className="w-2 h-2 rounded-full bg-yellow-400"></div>
        <div className="w-2 h-2 rounded-full bg-green-400"></div>
      </div>
    </div>
    
    <div className="grid grid-cols-2 gap-4 flex-1">
      <div className="bg-gray-50 p-4 rounded border border-gray-100 group hover:border-accent transition-colors">
        <Layout className="mb-3 text-gray-400 group-hover:text-accent" />
        <h5 className="font-bold text-sm mb-1">Frontend</h5>
        <p className="text-xs text-gray-500 font-mono">React, TypeScript, Tailwind, Next.js</p>
      </div>
      <div className="bg-gray-50 p-4 rounded border border-gray-100 group hover:border-accent transition-colors">
        <Database className="mb-3 text-gray-400 group-hover:text-accent" />
        <h5 className="font-bold text-sm mb-1">Backend</h5>
        <p className="text-xs text-gray-500 font-mono">Node.js, Python, PostgreSQL, Redis</p>
      </div>
      <div className="bg-gray-50 p-4 rounded border border-gray-100 group hover:border-accent transition-colors">
        <Cpu className="mb-3 text-gray-400 group-hover:text-accent" />
        <h5 className="font-bold text-sm mb-1">DevOps</h5>
        <p className="text-xs text-gray-500 font-mono">Docker, AWS, CI/CD Pipelines</p>
      </div>
      <div className="bg-gray-50 p-4 rounded border border-gray-100 group hover:border-accent transition-colors">
        <Zap className="mb-3 text-gray-400 group-hover:text-accent" />
        <h5 className="font-bold text-sm mb-1">AI/ML</h5>
        <p className="text-xs text-gray-500 font-mono">TensorFlow, OpenAI API, LangChain</p>
      </div>
    </div>
  </div>
);

// Visual for "Projects" - Code snippet / Terminal style
export const ProjectsVisual = () => (
  <div className="w-full h-full bg-[#1e1e1e] text-gray-300 p-6 rounded-lg font-mono text-sm shadow-2xl flex flex-col overflow-hidden relative">
    <div className="flex items-center justify-between mb-4 border-b border-gray-700 pb-2">
      <span className="text-xs text-gray-500">terminal — -zsh — 80x24</span>
    </div>
    <div className="space-y-4 z-10">
      <div>
        <span className="text-green-500">➜</span> <span className="text-blue-400">~</span> cd projects/adaline-clone
      </div>
      <div>
        <span className="text-green-500">➜</span> <span className="text-blue-400">adaline-clone</span> git log --oneline
      </div>
      <div className="text-gray-500 pl-4">
        <p><span className="text-yellow-500">a1b2c3d</span> feat: implemented sticky scroll</p>
        <p><span className="text-yellow-500">e5f6g7h</span> style: added dashed grid pattern</p>
        <p><span className="text-yellow-500">i9j0k1l</span> init: project setup</p>
      </div>
      <div>
        <span className="text-green-500">➜</span> <span className="text-blue-400">adaline-clone</span> npm run build
      </div>
      <div className="text-white pl-4">
        <p>Creating an optimized production build...</p>
        <p className="text-green-400">✓ Compiled successfully.</p>
        <p className="mt-2">
           File sizes after gzip:<br/>
           45.2 kB  build/static/js/main.js<br/>
           1.4 kB   build/static/css/main.css
        </p>
      </div>
      <div className="animate-pulse">
        <span className="text-green-500">➜</span> <span className="text-blue-400">adaline-clone</span> <span className="w-2 h-4 bg-gray-500 inline-block align-middle"></span>
      </div>
    </div>
    <div className="absolute right-0 bottom-0 opacity-10">
      <Code2 size={200} />
    </div>
  </div>
);

// Visual for "Vision" - Contact Card
export const VisionVisual = () => (
  <div className="w-full h-full flex items-center justify-center relative">
     <div className="absolute inset-0 bg-dashed-grid opacity-30"></div>
     
     <div className="bg-white p-8 max-w-sm w-full shadow-[8px_8px_0px_0px_rgba(15,31,24,1)] border-2 border-primary relative z-10">
       <h3 className="text-3xl font-bold mb-6">Let's Build.</h3>
       
       <div className="space-y-4">
         <a href="#" className="flex items-center justify-between group border-b border-gray-100 pb-2">
           <span className="font-mono text-sm text-gray-500">Email</span>
           <span className="font-medium flex items-center gap-2 group-hover:text-accent transition-colors">
             hello@johndoe.dev <ArrowUpRight size={14} />
           </span>
         </a>
         <a href="#" className="flex items-center justify-between group border-b border-gray-100 pb-2">
           <span className="font-mono text-sm text-gray-500">GitHub</span>
           <span className="font-medium flex items-center gap-2 group-hover:text-accent transition-colors">
             @johndoe <ArrowUpRight size={14} />
           </span>
         </a>
         <a href="#" className="flex items-center justify-between group border-b border-gray-100 pb-2">
           <span className="font-mono text-sm text-gray-500">LinkedIn</span>
           <span className="font-medium flex items-center gap-2 group-hover:text-accent transition-colors">
             /in/johndoe <ArrowUpRight size={14} />
           </span>
         </a>
       </div>

       <button className="w-full mt-8 bg-primary text-white py-3 font-mono text-sm hover:bg-accent transition-colors flex items-center justify-center gap-2">
         Download Resume <ArrowUpRight size={16} />
       </button>
     </div>
  </div>
);
