import React from 'react';

interface PhaseIndicatorProps {
  number: string;
  label: string;
  isActive: boolean;
  isCompleted: boolean;
  onClick: () => void;
}

export const PhaseIndicator: React.FC<PhaseIndicatorProps> = ({ 
  number, 
  label, 
  isActive, 
  isCompleted,
  onClick 
}) => {
  return (
    <button 
      onClick={onClick}
      className={`group flex items-center gap-3 transition-all duration-300 min-w-fit pr-4
        ${isActive ? 'opacity-100' : 'opacity-40 hover:opacity-70'}
      `}
    >
      {/* Circle Container */}
      <div className={`
        relative flex items-center justify-center w-10 h-10 rounded-full font-mono text-sm border transition-all duration-500
        ${isActive 
          ? 'border-primary bg-primary text-white scale-100' 
          : 'border-gray-300 border-dashed text-gray-500 scale-90'
        }
        ${isCompleted ? 'border-solid border-primary/50 text-primary bg-primary/5' : ''}
      `}>
        {number}
        
        {/* Active Ping Effect */}
        {isActive && (
          <span className="absolute -inset-1 rounded-full border border-primary/30 animate-pulse"></span>
        )}
      </div>

      {/* Label Text */}
      <div className="flex flex-col items-start">
        <span className={`text-sm font-medium tracking-wide ${isActive ? 'text-primary font-bold' : 'text-gray-500'}`}>
          {label}
        </span>
      </div>
      
      {/* Connector Line (Decorative) */}
      {isActive && (
         <div className="hidden sm:block h-px w-8 bg-primary/20 ml-2"></div>
      )}
    </button>
  );
};