import { ReactNode } from 'react';

export interface SectionData {
  id: string;
  stepNumber: string;
  title: string;
  subtitle: string;
  description: string;
  subPoints: {
    label: string;
    text: string;
  }[];
  visual: ReactNode;
}

export type SectionId = 'origins' | 'craft' | 'projects' | 'vision';
