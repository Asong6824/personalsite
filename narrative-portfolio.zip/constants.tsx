import React from 'react';
import { SectionData } from './types';
import { OriginsVisual, CraftVisual, ProjectsVisual, VisionVisual } from './components/Visuals';

export const SECTIONS: SectionData[] = [
  {
    id: 'origins',
    stepNumber: '01',
    title: 'Origins',
    subtitle: 'Where it all began',
    description: "I've always been fascinated by how things work. From taking apart radios as a kid to architecting distributed systems today, curiosity has been my constant driver. My journey into tech wasn't linear—it was an iterative process of experimentation, failure, and debugging.",
    subPoints: [
      { label: 'Philosophy', text: 'Clean code, clear communication.' },
      { label: 'Background', text: 'CS Degree @ University of Tech' },
      { label: 'Focus', text: 'Problem solving at scale' }
    ],
    visual: <OriginsVisual />
  },
  {
    id: 'craft',
    stepNumber: '02',
    title: 'Craft',
    subtitle: 'Tools of the trade',
    description: "I specialize in building performant web applications with a focus on user experience. I don't just write code; I design systems. My stack is modern, robust, and type-safe, allowing me to move fast without breaking things.",
    subPoints: [
      { label: 'Core', text: 'TypeScript, React, Node.js' },
      { label: 'Style', text: 'Tailwind CSS, Framer Motion' },
      { label: 'Deploy', text: 'Vercel, AWS, Docker' }
    ],
    visual: <CraftVisual />
  },
  {
    id: 'projects',
    stepNumber: '03',
    title: 'Work',
    subtitle: 'Building in public',
    description: "Talk is cheap. Show me the code. Over the years, I've contributed to open source, built SaaS products from scratch, and led engineering teams. Here are a few highlights where I've turned abstract requirements into shipping products.",
    subPoints: [
      { label: 'SaaS', text: 'Built a CRM for non-profits' },
      { label: 'Open Source', text: 'Maintainer of 2 popular UI libs' },
      { label: 'Enterprise', text: 'Migrated legacy app to Micro-frontends' }
    ],
    visual: <ProjectsVisual />
  },
  {
    id: 'vision',
    stepNumber: '04',
    title: 'Vision',
    subtitle: 'What comes next',
    description: "I am currently looking for opportunities where I can merge my technical expertise with my product sense. I thrive in environments that value autonomy, mastery, and purpose. If you're building something that matters, I want to hear about it.",
    subPoints: [
      { label: 'Goal', text: 'Impactful Engineering Leadership' },
      { label: 'Interest', text: 'AI Agents, Local-First Software' },
      { label: 'Status', text: 'Open for consulting & full-time' }
    ],
    visual: <VisionVisual />
  }
];