
import React, { useState, useEffect, useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';
import { fetchDeconstruction } from './services/geminiService';
import { ArrowRight, Compass, Scissors, Maximize2, Menu, Activity, Globe } from 'lucide-react';

const CaliperSVG = ({ progress }: { progress: any }) => {
  const slide = useTransform(progress, [0, 0.5, 1], [-20, 0, 20]);
  return (
    <svg width="600" height="400" viewBox="0 0 600 400" fill="none" className="opacity-20 stroke-current text-black">
      <path d="M50 150 L50 250 L80 250 L80 150 Z" strokeWidth="1" />
      <motion.g style={{ x: slide }}>
        <path d="M120 150 L120 250 L150 250 L150 150 Z" strokeWidth="1" />
        <path d="M120 200 L550 200" strokeWidth="0.5" strokeDasharray="4 4" />
      </motion.g>
      <path d="M50 200 L550 200" strokeWidth="1" />
      {Array.from({ length: 20 }).map((_, i) => (
        <line key={i} x1={80 + i * 25} y1="200" x2={80 + i * 25} y2={i % 5 === 0 ? "185" : "192"} strokeWidth="0.5" />
      ))}
    </svg>
  );
};

const ThreadSVG = () => {
  return (
    <svg width="600" height="600" viewBox="0 0 600 600" fill="none" className="opacity-20 stroke-current text-white">
      <motion.path 
        d="M100 100 Q 300 50, 500 100 T 500 500 Q 300 550, 100 500 T 100 100" 
        strokeWidth="0.5"
        animate={{ 
          d: [
            "M100 100 Q 300 80, 500 100 T 500 500 Q 300 520, 100 500 T 100 100",
            "M100 110 Q 310 100, 490 110 T 510 490 Q 290 510, 110 490 T 100 110",
            "M100 100 Q 300 80, 500 100 T 500 500 Q 300 520, 100 500 T 100 100"
          ] 
        }}
        transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
      />
      <circle cx="300" cy="300" r="150" strokeWidth="0.2" strokeDasharray="2 2" />
    </svg>
  );
};

const App: React.FC = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const [logicContent, setLogicContent] = useState<any>(null);
  const [aestheticContent, setAestheticContent] = useState<any>(null);

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end end"]
  });

  const smoothScroll = useSpring(scrollYProgress, { stiffness: 100, damping: 30, restDelta: 0.001 });

  // Animations Mapping
  const dividerPosition = useTransform(smoothScroll, [0, 0.2, 0.4, 0.6, 0.8, 1], ["50%", "50%", "95%", "5%", "50%", "50%"]);
  const heroScale = useTransform(smoothScroll, [0, 0.2], [1, 1.1]);
  const heroOpacity = useTransform(smoothScroll, [0, 0.15], [1, 0]);
  const contentY = useTransform(smoothScroll, [0, 0.2], [0, -100]);

  useEffect(() => {
    const load = async () => {
      const [l, a] = await Promise.all([fetchDeconstruction('logic'), fetchDeconstruction('aesthetics')]);
      setLogicContent(l);
      setAestheticContent(a);
    };
    load();
  }, []);

  return (
    <div ref={containerRef} className="relative h-[500vh] font-sans selection:bg-black selection:text-white">
      {/* Magazine Frame Header */}
      <header className="fixed top-0 inset-x-0 h-24 z-[100] px-10 flex items-center justify-between mix-blend-difference text-white pointer-events-none">
        <div className="flex flex-col">
          <span className="font-mono-space text-[10px] tracking-[0.4em] uppercase opacity-60">Issue No. 01 / Archive 2025</span>
          <span className="font-serif italic text-sm">Dualistic Perspectives</span>
        </div>
        <div className="flex gap-8 items-center pointer-events-auto">
          <button className="font-mono-space text-[10px] uppercase tracking-widest hover:opacity-50 transition-opacity">Index</button>
          <button className="font-mono-space text-[10px] uppercase tracking-widest hover:opacity-50 transition-opacity">Philosophy</button>
          <Menu size={18} strokeWidth={1} />
        </div>
      </header>

      {/* Background System */}
      <div className="fixed inset-0 h-screen w-full flex overflow-hidden">
        <motion.div 
          style={{ width: dividerPosition }}
          className="h-full bg-[#8C9191] relative flex items-center justify-center border-r border-black/5"
        >
          <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'linear-gradient(#000 0.5px, transparent 0.5px), linear-gradient(90deg, #000 0.5px, transparent 0.5px)', backgroundSize: '60px 60px' }} />
          <motion.div style={{ scale: heroScale }} className="relative z-10">
            <CaliperSVG progress={smoothScroll} />
          </motion.div>
        </motion.div>

        <motion.div 
          style={{ flex: 1 }}
          className="h-full bg-[#D68E95] relative flex items-center justify-center"
        >
          <div className="absolute inset-0 opacity-10">
             <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
               <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                 <circle cx="20" cy="20" r="0.5" fill="white" />
               </pattern>
               <rect width="100%" height="100%" fill="url(#grid)" />
             </svg>
          </div>
          <motion.div style={{ scale: heroScale }} className="relative z-10">
            <ThreadSVG />
          </motion.div>
        </motion.div>
      </div>

      {/* Section 1: Editorial Cover Title */}
      <section className="h-screen relative z-40 flex flex-col items-center justify-center pointer-events-none">
        <motion.div style={{ opacity: heroOpacity, y: contentY }} className="text-center mix-blend-difference text-white">
          <span className="font-mono-space text-[12px] tracking-[0.6em] uppercase mb-6 block opacity-70">A Study in Symmetry</span>
          <h1 className="text-[12vw] font-serif leading-[0.8] tracking-tighter mb-4">
            DUALISM
          </h1>
          <div className="flex items-center justify-center gap-12 mt-12 overflow-hidden">
             <div className="h-px w-32 bg-white/30" />
             <div className="flex gap-8">
               <span className="font-mono-space text-xs uppercase tracking-widest">Logic</span>
               <span className="font-serif italic text-xl">&</span>
               <span className="font-serif text-xl">Aesthetics</span>
             </div>
             <div className="h-px w-32 bg-white/30" />
          </div>
        </motion.div>
      </section>

      {/* Section 2: Logic Deconstruction (Magazine Layout) */}
      <section className="h-screen relative z-50 flex items-center px-10 md:px-32">
        <motion.div 
          style={{ opacity: useTransform(smoothScroll, [0.2, 0.3, 0.45, 0.5], [0, 1, 1, 0]) }}
          className="max-w-6xl w-full grid grid-cols-12 gap-8 text-neutral-900"
        >
          <div className="col-span-1 border-r border-black/10 py-10">
            <span className="font-mono-space text-[10px] uppercase [writing-mode:vertical-lr] tracking-[0.4em] opacity-40">Precision_Structure</span>
          </div>
          <div className="col-span-11 md:col-span-7 py-10">
            <div className="flex items-center gap-4 mb-12">
              <span className="font-mono-space text-xs px-3 py-1 border border-black/20 rounded-full">Phase 01</span>
              <div className="h-px flex-1 bg-black/10" />
            </div>
            <h2 className="text-[8vw] md:text-[6vw] font-serif leading-none mb-10 tracking-tight">
              {logicContent?.title || "Surgical Clarity"}
            </h2>
            <p className="text-xl md:text-2xl font-light mb-12 leading-relaxed max-w-xl opacity-80">
              {logicContent?.description || "Logic is the architecture of the mind, a skeletal framework where truth is measured in microns and verified by gravity."}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pt-12 border-t border-black/10">
              {logicContent?.principles.map((p: string, i: number) => (
                <div key={i} className="group">
                  <span className="font-mono-space text-[10px] block mb-4 text-black/40">AXIOM 0{i+1}</span>
                  <p className="text-sm font-medium leading-relaxed tracking-wide group-hover:translate-x-1 transition-transform cursor-default">{p}</p>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </section>

      {/* Section 3: Aesthetics Deconstruction (Magazine Layout) */}
      <section className="h-screen relative z-50 flex items-center justify-end px-10 md:px-32">
        <motion.div 
          style={{ opacity: useTransform(smoothScroll, [0.55, 0.65, 0.75, 0.85], [0, 1, 1, 0]) }}
          className="max-w-6xl w-full grid grid-cols-12 gap-8 text-white text-right"
        >
          <div className="col-span-11 md:col-span-7 py-10">
            <div className="flex items-center gap-4 mb-12 justify-end">
              <div className="h-px flex-1 bg-white/20" />
              <span className="font-mono-space text-xs px-3 py-1 border border-white/30 rounded-full">Phase 02</span>
            </div>
            <h2 className="text-[8vw] md:text-[6vw] font-serif leading-none mb-10 tracking-tight italic">
              {aestheticContent?.title || "Visceral Grace"}
            </h2>
            <p className="text-xl md:text-2xl font-light mb-12 leading-relaxed max-w-xl ml-auto opacity-90">
              {aestheticContent?.description || "Aesthetics is the emotional resonant, a delicate silk thread weaving through structural mass to find the soul in the silent spaces."}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pt-12 border-t border-white/20">
              {aestheticContent?.principles.map((p: string, i: number) => (
                <div key={i} className="group">
                  <span className="font-mono-space text-[10px] block mb-4 text-white/40">SENSATION 0{i+1}</span>
                  <p className="text-sm font-medium leading-relaxed tracking-wide group-hover:-translate-x-1 transition-transform cursor-default">{p}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="col-span-1 border-l border-white/10 py-10 flex justify-end">
            <span className="font-mono-space text-[10px] uppercase [writing-mode:vertical-rl] tracking-[0.4em] opacity-50">Ethereal_Emotion</span>
          </div>
        </motion.div>
      </section>

      {/* Section 4: Final Synthesis - The "Manifesto" */}
      <section className="h-screen relative z-50 flex flex-col items-center justify-center px-10">
        <motion.div 
          style={{ opacity: useTransform(smoothScroll, [0.9, 1], [0, 1]) }}
          className="max-w-4xl text-center"
        >
          <span className="font-mono-space text-[10px] tracking-[0.5em] uppercase mb-12 block opacity-50 mix-blend-difference text-white">Editorial Conclusion</span>
          <h2 className="text-5xl md:text-8xl font-serif mb-16 mix-blend-difference text-white leading-[0.9]">
            The <span className="italic">Caliper</span> Measures,<br />
            The <span className="italic">Thread</span> Connects.
          </h2>
          <p className="text-lg md:text-xl font-light mb-20 opacity-70 mix-blend-difference text-white max-w-2xl mx-auto leading-relaxed">
            True excellence is found not in the dominance of one, but in the absolute symmetry of both. We curate experiences that are mathematically sound and emotionally profound.
          </p>
          <div className="flex flex-col md:flex-row gap-8 justify-center items-center">
            <button className="group relative px-16 py-5 overflow-hidden transition-all duration-700 hover:scale-105">
               <div className="absolute inset-0 bg-white/10 backdrop-blur-md group-hover:bg-white transition-colors duration-700" />
               <div className="absolute inset-0 border border-white/20" />
               <span className="relative z-10 font-mono-space text-[11px] uppercase tracking-[0.3em] text-white group-hover:text-black flex items-center gap-4 transition-colors">
                 Enter The Archive <ArrowRight size={14} />
               </span>
            </button>
          </div>
        </motion.div>
      </section>

      {/* Editorial Footer / Navigation Context */}
      <footer className="fixed bottom-0 inset-x-0 h-16 z-[100] px-10 flex items-center justify-between mix-blend-difference text-white text-[9px] font-mono-space uppercase tracking-[0.3em] opacity-50">
        <div className="flex gap-10">
          <span className="flex items-center gap-2"><Globe size={10} strokeWidth={1}/> Global Edition</span>
          <span className="flex items-center gap-2"><Activity size={10} strokeWidth={1}/> Real-time Synthesis</span>
        </div>
        <div className="flex gap-4">
          <span>{Math.round(smoothScroll.get() * 100)}% Through the Lens</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
