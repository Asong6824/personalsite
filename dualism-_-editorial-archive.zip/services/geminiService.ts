
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const fetchDeconstruction = async (topic: 'logic' | 'aesthetics') => {
  const prompt = topic === 'logic' 
    ? "Deconstruct 'Logic' as an editorial theme. Focus on the mathematical sublime, the cold precision of industrial measurement (calipers), and the structural integrity of thought. Provide a JSON response with: title (brief, impactful), description (poetic yet analytical), and 3 core philosophical axioms."
    : "Deconstruct 'Aesthetics' as an editorial theme. Focus on the ephemeral quality of silk threads, the warmth of human intuition, and the visceral impact of color. Provide a JSON response with: title (brief, impactful), description (sensory and evocative), and 3 core philosophical axioms.";

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          description: { type: Type.STRING },
          principles: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["title", "description", "principles"]
      }
    }
  });

  return JSON.parse(response.text);
};
