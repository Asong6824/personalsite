
export interface ContentSection {
  title: string;
  description: string;
  points: string[];
}

export enum Side {
  LOGIC = 'LOGIC',
  AESTHETICS = 'AESTHETICS'
}
